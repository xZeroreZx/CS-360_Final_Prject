package com.assignments.thewhoaweightapp;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.assignments.thewhoaweightapp.provider.DataProvider;
import com.assignments.thewhoaweightapp.provider.UserData;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private ContentResolver someCR;

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "weightapp.db";
    public static final String TABLE_WEIGHTS = "user_weights";
    public static final String TABLE_USER = "users";

    public static final String COLUMN_ID ="_id";
    public static final String COLUMN_DATES = "date_entered";
    public static final String COLUMN_WEIGHTS = "weight_entered";
    public static final String COLUMN_GOAL = "to_goal";

    public static final String COLUMN_USERNAME ="username";
    public static final String COLUMN_PASSWORD = "password";

    /**
     *
     * @param context
     * @param name
     * @param factory
     * @param version
     */
    public DBHandler(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
        someCR = context.getContentResolver();
    }

    /**
     * Create All tables
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_WEIGHTS_TABLE = "CREATE TABLE " +
                TABLE_WEIGHTS +"(" +
                COLUMN_ID + " INTEGER PRIMARY KEY," +
                COLUMN_DATES
                + " TEXT," + COLUMN_WEIGHTS + " TEXT" +
                 "TEXT," + COLUMN_GOAL +")";

        String CREATE_USERS_TABLE = "CREATE TABLE " +
                TABLE_USER +"(" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY," +
                COLUMN_PASSWORD
                + " TEXT" + ")";

        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_WEIGHTS_TABLE);
    }

    /**
     * OnUpgrade
     * @param db
     * @param oldVersion
     * @param newVersion
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_WEIGHTS);
        onCreate(db);
    }

    public User findUser(String username,String password){
        String[] projection = {COLUMN_USERNAME, COLUMN_PASSWORD};

        String selection = "username =\"" +username +"\" AND password=\""+password +"\"";

        Cursor cursor = someCR.query(UserData.CONTENT_URI, projection,selection, null,null);

        User user = new User();
        System.out.println(cursor.moveToFirst());
        if(cursor.moveToFirst()){
            cursor.moveToFirst();
            user.setUsername(cursor.getString(0));
            user.setPassword((cursor.getString(1)));
            cursor.close();
        }else{
            user =null;
        }
        return user;
    }
    public boolean addUser(User user){
        ContentValues values=new ContentValues();
        values.put(COLUMN_USERNAME, user.getUsername());
        values.put(COLUMN_PASSWORD, user.getPassword());

        someCR.insert(UserData.CONTENT_URI,values);
        return true;
    }

    /**
     *
     * @param date
     */

    public void addWeight(Dates date){
        if(findDate(date.getDateName()) !=null){
            updateWeight(date);
        }else {
            ContentValues values = new ContentValues();
            values.put(COLUMN_ID, date.getID());
            values.put(COLUMN_DATES, date.getDateName());
            values.put(COLUMN_WEIGHTS, date.getWeight());
            values.put(COLUMN_GOAL, date.getGoal());

            someCR.insert(DataProvider.CONTENT_URI, values);
        }
    }

    /**
     * @param date
     */
    public void updateWeight(Dates date){
        String selection = "date_entered =\"" + date.getDateName() +"\"";
        ContentValues values=new ContentValues();
        values.put(COLUMN_ID, date.getID());
        values.put(COLUMN_DATES, date.getDateName());
        values.put(COLUMN_WEIGHTS, date.getWeight());
        values.put(COLUMN_GOAL, date.getGoal());

        someCR.update(DataProvider.CONTENT_URI,values,selection,null);
    }

    public Dates findDate(String datename){
        String[] projection = {COLUMN_ID, COLUMN_DATES,COLUMN_WEIGHTS, COLUMN_GOAL};

        String selection = "date_entered =\"" +datename +"\"";
        Cursor cursor = someCR.query(DataProvider.CONTENT_URI, projection,selection, null,null);

        Dates date = new Dates();

        if(cursor.moveToFirst()){
            cursor.moveToFirst();

            date.setID(Integer.parseInt(cursor.getString(0)));
            date.setDateName((cursor.getString(1)));
            date.setWeight(cursor.getInt(2));
            date.setGoal(cursor.getInt(3));
            cursor.close();
        }else{
            date =null;
        }
        return date;
    }

    public  boolean deleteDate(String datename){
        boolean result = false;

        String selection = "date_entered = \"" +datename + "\"";
        int rowsDeleted = someCR.delete(DataProvider.CONTENT_URI,selection,null);

        if(rowsDeleted > 0)
            result = true;

        return result;
    }


    public ArrayList<Dates> selectAllDates() {
        ArrayList<Dates> dateList = new ArrayList<>();
        String[] projection = {COLUMN_ID, COLUMN_DATES, COLUMN_WEIGHTS, COLUMN_GOAL};

        String selection = "";
        Cursor cursor = someCR.query(DataProvider.CONTENT_URI, projection, null, null, null);

        while (cursor.moveToNext()) {
            dateList.add(new Dates(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getInt(1), cursor.getInt(1)));
        }
        cursor.close();

        return dateList;
    }
}
