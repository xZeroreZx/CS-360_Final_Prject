package com.assignments.thewhoaweightapp;

public class Dates {
    private int _id;
    private String _date;
    private int _weight;
    private int _goal;


    //Constructors
    public Dates() {

    }

    public Dates(int id, String date, int weight, int goal) {
        this._id = id;
        this._date = date;
        this._weight = weight;
        this._goal = goal;
    }
    /**
     *
     * @return
     */
    public int getID() {
        return _id;
    }

    public void setID(int id) {
        this._id = id;
    }

    public String getDateName() {
        return _date;
    }

    public void setDateName(String date) {
        this._date = date;
    }

    public int getWeight() {
        return _weight;
    }

    public void setWeight(int weight) {
        this._weight = weight;
    }

    public int getGoal() {
        return _goal;
    }

    public void setGoal(int goal) {
        this._goal = goal;
    }
}