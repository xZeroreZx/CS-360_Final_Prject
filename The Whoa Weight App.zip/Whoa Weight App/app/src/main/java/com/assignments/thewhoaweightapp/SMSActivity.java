package com.assignments.thewhoaweightapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private int RECIEVE_SMS_PERMISSION_CODE =1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
        Button grant_permission =(Button) findViewById(R.id.grant_permission_btn);

        grant_permission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekPermission(v);
                //Toast.makeText(SMSActivity.this,"I was clicked",Toast.LENGTH_SHORT).show();

            }
        });
        if (ContextCompat.checkSelfPermission(
                SMSActivity.this, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(SMSActivity.this, WeightActivity.class);
            startActivity(intent);
        }
    }

    /**
     *
     * @param view
     */
    public void seekPermission(View view) {
        if (ContextCompat.checkSelfPermission(
                SMSActivity.this, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(SMSActivity.this, "Permission already granted", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(SMSActivity.this, WeightActivity.class);
            startActivity(intent);
        } else{

            if (ActivityCompat.shouldShowRequestPermissionRationale(SMSActivity.this, Manifest.permission.SEND_SMS)) {

                new AlertDialog.Builder(this)
                        .setTitle("Permmision required")
                        .setMessage("This permission is required so that you may recieve automated system notifications")
                        .setPositiveButton("GRANT", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(SMSActivity.this, new String[]{Manifest.permission.SEND_SMS}, RECIEVE_SMS_PERMISSION_CODE);
                            }
                        })
                        .setNegativeButton("DENY", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .create().show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, RECIEVE_SMS_PERMISSION_CODE);

            }
        }
    }
    /**
     *
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RECIEVE_SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
        Intent intent = new Intent(SMSActivity.this, WeightActivity.class);
        startActivity(intent);
    }
}
