package com.assignments.thewhoaweightapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class WeightActivity extends AppCompatActivity {

    private TableLayout tl;
    private EditText dateentered, weightentered;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);
        dateentered = findViewById(R.id.some_date_input);
        weightentered = findViewById(R.id.some_weight_input);
        tl = findViewById(R.id.tableLayout);
        Button addWeight = findViewById(R.id.addWeight);
        addWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(WeightActivity.this));
                WeightActivity.this.startActivity(intent);

            }
        });

        Button addGoal = findViewById(R.id.addGoal);
        addGoal.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(String.valueOf(WeightActivity.this));
                WeightActivity.this.startActivity(intent);
            }
        }));
        populateTable();
    }
    /**
     * Add new weight
     * @param view
     */

    public void newWeight (View view) {
        String e_datename = dateentered.getText().toString(), e_weight = weightentered.getText().toString();
        if (e_datename.isEmpty() || e_weight.isEmpty()) {
            Toast.makeText(this, "Please Fill in All the fields", Toast.LENGTH_SHORT).show();
            return;
        }

        DBHandler dbHandler = new DBHandler(this, null, null, 1);

        Dates date = new Dates();

        dbHandler.addWeight(date);


        dateentered.setText("");
        weightentered.setText("");
        populateTable();
    }
    /**
     * Lookup date
     * @param view
     */
    public void lookUpDate (View view){
        DBHandler dbHandler = new DBHandler(this,null,null,1);
        TableRow row =(TableRow)view.getParent();
        TextView textView = (TextView)row.getChildAt(1);

        Dates product = dbHandler.findDate(textView.getText().toString());
        if(product != null){
            dateentered.setText(product.getDateName());

            weightentered.setText(product.getWeight());
        }else{
            dateentered.setText("No Match Found");
        }
    }

    /**
     * Remove date
     * @param view
     * @return
     */
    public boolean removeDate (View view){
        DBHandler dbHandler = new DBHandler(this,null,null,1);
        TableRow row =(TableRow)view.getParent();
        TextView textView = (TextView)row.getChildAt(1);

        boolean result = dbHandler.deleteDate(textView.getText().toString());

        if(result){
            dateentered.setText("Record Deleted");
            weightentered.setText("");
        }else
            dateentered.setText("No Match Found");
        return result;
    }
    /**
     * Delete row
     * @param v
     */
    public void deleteRow(View v){
        View row =(View)v.getParent();
        ViewGroup container =((ViewGroup)row.getParent());
        container.removeView(row);
        container.invalidate();
    }

    /**
     * Populate Tables
     */
        public void populateTable(){

            DBHandler dbHandler = new DBHandler(this, null, null,1);
            ArrayList<Dates> dateList = dbHandler.selectAllDates();
            int count =tl.getChildCount();
            tl.removeViews(1,count-1);
            for(Dates date:dateList) {
                TableRow tr = new TableRow(this);
                tr.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                tr.setBackgroundColor(Color.parseColor("#DAE8FC"));
                tr.setPadding(5, 5, 5, 5);

                TextView tx1= new TextView(this);
                TextView tx2= new TextView(this);
                TextView tx3= new TextView(this);


                tx1.setText(String.valueOf(date.getID()));

                tx2.setText(date.getWeight());
                tx3.setText(untilGoal(String.valueOf(date.getGoal() - date.getWeight())));

                ImageView img = new ImageView(this);
                img.setImageResource(R.drawable.ic_action_delete);

                img.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (WeightActivity.this.removeDate(v)) WeightActivity.this.deleteRow(v);
                    }
                });
                ImageView img1 = new ImageView(this);
                img1.setImageResource(R.drawable.ic_action_edit);

                tr.addView(tx1);
                tr.addView(tx2);
                tr.addView(img);
                tr.addView(img1);
                tl.addView(tr);
            }
        }


        public String untilGoal (String goalUpdate){
            sendSMS(goalUpdate);
            return String.valueOf(goalUpdate);
        }
    /**
     * Send SMS
     * @param goalUpdate
     */
        public void sendSMS (String goalUpdate) {
            String phoneNo = "+223456789101";
            String message = goalUpdate + " You're almost there";

            try {
                SmsManager smgr = SmsManager.getDefault();
                smgr.sendTextMessage(phoneNo, null, message, null, null);
                Toast.makeText(WeightActivity.this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(WeightActivity.this, "SMS Failed to Send, Please try again", Toast.LENGTH_SHORT).show();
            }
        }
}