package com.assignments.thewhoaweightapp.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;

import com.assignments.thewhoaweightapp.DBHandler;

public class DataProvider extends ContentProvider {

    private static final String AUTHORITY = "com.example.whoaweight.provider.DataProvider";
    private static final String TABLE_WEIGHTS = "user_weights";
    public static final Uri CONTENT_URI = Uri.parse("content://"+ AUTHORITY +"/"+ TABLE_WEIGHTS);

    public static final int COLUMN_DATES = 1;
    public static final int COLUMN_ID =2;

    private static final UriMatcher sURIMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        sURIMatcher.addURI(AUTHORITY, TABLE_WEIGHTS, COLUMN_DATES);
        sURIMatcher.addURI(AUTHORITY, TABLE_WEIGHTS + "/#", COLUMN_ID);
    }

    private DBHandler myDB;
    public DataProvider() {
    }
    /**
     * Delete item in Products table
     * @param uri
     * @param selection
     * @param selectionArgs
     * @return
     */
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int uriType = sURIMatcher.match(uri);
        SQLiteDatabase sqlDB = myDB.getWritableDatabase();
        int rowsDeleted = 0;

        switch (uriType) {
            case COLUMN_DATES:
                rowsDeleted = sqlDB.delete(DBHandler.TABLE_WEIGHTS,selection,selectionArgs);
                break;
            case COLUMN_ID:
                String id = uri.getLastPathSegment();
                if(TextUtils.isEmpty(selection)) {
                    rowsDeleted = sqlDB.delete(DBHandler.TABLE_WEIGHTS, DBHandler.COLUMN_ID + "=" + id, null);
                } else{
                    rowsDeleted = sqlDB.delete(DBHandler.TABLE_WEIGHTS, DBHandler.COLUMN_ID + "=" + id + " and " +
                            selection,selectionArgs);
                }
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: "+ uri);

        }
        getContext().getContentResolver().notifyChange(uri,null);
        return rowsDeleted;
    }
    /**
     *
     * @param uri
     * @return
     */
    @Override
    public String getType(Uri uri) {

        // at the given URI.
        throw new UnsupportedOperationException("Nothing to Display");
    }
    /**
     * Insert to products database
     * @param uri
     * @param values
     * @return
     */
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        int uriType = sURIMatcher.match(uri);
        SQLiteDatabase sqlDB = myDB.getWritableDatabase();

        long id = 0;
        switch (uriType) {
            case COLUMN_DATES:
                id = sqlDB.insert(DBHandler.TABLE_WEIGHTS, null, values);
                break;
            default:
                throw new IllegalArgumentException("URI Not Available: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return uri.parse(TABLE_WEIGHTS + "/" + id);

    }
    /**
     *
     * @return
     */
    @Override
    public boolean onCreate() {
        myDB = new DBHandler(getContext(),null, null,1);
        return false;
    }
    /**
     * Query from Products table
     * @param uri
     * @param projection
     * @param selection
     * @param selectionArgs
     * @param sortOrder
     * @return
     */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
        queryBuilder.setTables(DBHandler.TABLE_WEIGHTS);

        int uriType = sURIMatcher.match(uri);

        switch(uriType) {
            case COLUMN_ID:
                queryBuilder.appendWhere(DBHandler.COLUMN_ID + "="
                        + uri.getLastPathSegment());
                break;
            case COLUMN_DATES:
                break;
            default:
                throw new IllegalArgumentException("Unknown URI");
        }

        Cursor cursor = queryBuilder.query(myDB.getReadableDatabase(),projection,selection, selectionArgs,null,null,sortOrder);
        cursor.setNotificationUri(getContext().getContentResolver(),uri);

        return cursor;
    }
    /**
     * Update  Products table
     * @param uri
     * @param values
     * @param selection
     * @param selectionArgs
     * @return number rows updated
     */
    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        int uriType = sURIMatcher.match(uri);
        SQLiteDatabase sqlDB = myDB.getWritableDatabase();
        int rowsUpdated =0;

        switch(uriType) {
            case COLUMN_DATES:
                rowsUpdated = sqlDB.update(DBHandler.TABLE_WEIGHTS,values,selection,selectionArgs);
                break;
            case COLUMN_ID:
                String id = uri.getLastPathSegment();
                if(TextUtils.isEmpty(selection)){
                    rowsUpdated = sqlDB.update(DBHandler.TABLE_WEIGHTS,values, DBHandler.COLUMN_ID + "=" +id,null);
                } else {
                    rowsUpdated = sqlDB.update(DBHandler.TABLE_WEIGHTS, values, DBHandler.COLUMN_ID + "="+id + " and " +
                            selection,selectionArgs);
                }
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: "+ uri);

        }
        getContext().getContentResolver().notifyChange(uri,null);
        return rowsUpdated;
    }
}


